import 'dart:io';

import 'package:args/args.dart';
import 'package:convert/convert.dart';
import 'package:crypto/crypto.dart';

import 'file_supplier.dart';
import 'helper.dart';

/// Shows a message how to use the program.
/// [message]: null or an error message
/// [parser]: delivers the description of the program's options
void usage(String message, {ArgParser parser}) {
  print('''Usage: ddouble [<options>] [<file1> [<file2>...]]
  Find files with the same content in directory trees.
  <fileN>: a directory or a shell file pattern like '*.txt'
    or both like /home/*.txt

Examples:
 ddouble
 ddouble -V2 /opt/*.png /home -V2
<option>:''');
  if (parser == null) {
    print('  Use -h or --help for more info');
  } else {
    print(parser.usage);
  }
  if (message != null) {
    print('+++ ' + message);
  }
}

class DoubleFinder {
  static bool storeResult = false;
  final startTime = DateTime.now();
  Map<int, List<FileInfo>> processedFiles = {};
  final int verboseLevel;
  final startLength;
  final blockSize;
  int startBlockCount = 0;
  int fullBlockCounts = 0;
  int fullBlockFiles = 0;
  int doubles = 0;
  final lines = <String>[];
  var hashBuilder = md5;
  DoubleFinder({this.verboseLevel, this.blockSize, this.startLength});

  // Adds all boolean options to the argument [parser].
  /// Finds the duplicates in a list of [filePatterns].
  void find(List<String> filePatterns, FileOptions fileOptions) {
    fileOptions.yieldDirectory =
        fileOptions.yieldLinkToDirectory = fileOptions.yieldLinkToFile = false;
    fileOptions.recursive = true;
    final supplier = FileSupplier(
        fileOptions: fileOptions,
        filePatterns: filePatterns,
        verboseLevel: verboseLevel);
    final toRemove = <FileInfo>[];
    for (var filename in supplier.next()) {
      final file = supplier.currentEntity as File;
      final size = file.lengthSync();
      if (size == 0){
        continue;
      }
      var newEntry = FileInfo(filename, size);
      if (!processedFiles.containsKey(size)) {
        if (verboseLevel >= 4) {
          print('= new size $size');
        }
        processedFiles[size] = [newEntry];
        continue;
      }
      for (var processedFile in processedFiles[size]) {
        processedFile.hashStart ??= calcHash(file, calculateStartBlock: true);
        if (processedFile.hashStart == null) {
          toRemove.add(processedFile);
          continue;
        }
        newEntry.hashStart ??= calcHash(file, calculateStartBlock: true);
        if (newEntry.hashStart == null) {
          newEntry = null;
          break;
        }
        if (processedFile.hashStart == newEntry.hashStart) {
          if (verboseLevel >= 4) {
            print('= start block is the same: $filename ${processedFile.name}');
          }
          processedFile.hashFull ??=
              calcHash(File(processedFile.name), calculateStartBlock: false);
          if (processedFile.hashFull == null) {
            toRemove.add(processedFile);
            continue;
          }
          newEntry.hashFull ??= calcHash(file, calculateStartBlock: false);
          if (newEntry.hashFull == null) {
            newEntry = null;
            break;
          }
          if (processedFile.hashFull == newEntry.hashFull) {
            doubles++;
            final line = '${newEntry.name} = ${processedFile.name} size: $size';
            if (verboseLevel >= 2) {
              if (storeResult) {
                lines.add(line);
              } else {
                print(line);
              }
            }
            // we search only one duplicate.
            break;
          }
        }
      }
      for (var processedFile in toRemove) {
        processedFiles[size].remove(processedFile);
      }
      toRemove.clear();
      if (newEntry != null) {
        processedFiles[size].add(newEntry);
      }
    }
    if (verboseLevel >= 1) {
      print('= duplicates: $doubles start blocks: $startBlockCount full blocks: $fullBlockFiles files with $fullBlockCounts blocks');
      print(supplier.summary.join('\n'));
      final diff = DateTime.now().difference(startTime);
      final milliSeconds =
          (diff.inMilliseconds % 1000).toString().padLeft(3, '0');
      print(
          '= runtime: ${diff.inHours}h${diff.inMinutes % 60}m${diff.inSeconds % 60}.$milliSeconds');
    }
    if (!DoubleFinder.storeResult) {
      // Exit at once: release resources faster.
      exit(0);
    }
  }

  // Adds all not boolean options to the argument [parser].
  static void addFlags(ArgParser parser) {
    parser.addFlag('help',
        abbr: 'h', help: 'Show the command description', negatable: false);
  }

  static void addOptions(ArgParser parser) {
    parser.addOption('block-length',
        abbr: 'b',
        help: 'length of a block for hashing',
        defaultsTo: (8 * 1024 * 1024).toString());
    parser.addOption('start-length',
        abbr: 's',
        help: 'length of the start block (used for the first hash value)',
        defaultsTo: '4096');
    parser.addOption('excluded',
        abbr: 'x',
        help: 'A regular expression for files to skip, e.g. ".*\.(bak|sic)"');
    parser.addOption('excluded-dirs',
        abbr: 'X',
        help:
            'A regular expression for directory to skip, e.g. "test|\.git|\.config');
    parser.addOption('verbose-level',
        abbr: 'V',
        help: '0: no additional info 1: summary 2: detail 3: loop 4: fine',
        defaultsTo: '2');
  }

  /// Calculates the hash value of the [file].
  /// If [calculateStartBlock] is true the begin of the file is processed.
  /// Otherwise the whole file content.
  /// Returns an instance of [Digest] containing the hash value.
  Digest calcHash(File file, {bool calculateStartBlock}) {
    Digest rc;
    try {
      final file2 = file.openSync();
      if (calculateStartBlock) {
        final buffer = file2.readSync(startLength);
        rc = hashBuilder.convert(buffer);
        if (calculateStartBlock) {
          startBlockCount++;
        } else {
          fullBlockCounts++;
        }
      } else {
        fullBlockFiles++;
        var output = AccumulatorSink<Digest>();
        var input = hashBuilder.startChunkedConversion(output);
        try {
          do {
            final buffer = file2.readSync(blockSize);
            if (buffer.isEmpty) {
              break;
            }
            input.add(buffer);
            if (calculateStartBlock) {
              startBlockCount++;
            } else {
              fullBlockCounts++;
            }
          } while (true);
        } finally {
          input.close();
          rc = output.events.single;
        }
      }
      file2.close();
    } on FileSystemException {
      rc = null;
    }
    return rc;
  }

  /// Executes the total search defined by the program [arguments].
  static DoubleFinder execute(List<String> arguments) {
    DoubleFinder finder;
    final parser = ArgParser();
    addFlags(parser);
    addOptions(parser);
    try {
      final results = parser.parse(arguments);
      final intArgs = ['verbose-level', 'block-length', 'start-length'];
      if (results['help']) {
        usage(null, parser: parser);
      } else if (testIntArguments(results, intArgs, usage) &&
          testRegExpArguments(results, ['excluded', 'excluded-dirs'], usage)) {
        if (results.rest.isEmpty) {
          usage('too few arguments', parser: parser);
        } else {
          finder = DoubleFinder(
              verboseLevel: intValue(results['verbose-level']),
              blockSize: intValue(results['block-length']),
              startLength: intValue(results['start-length']));
          final fileOptions = FileOptions.fromArgument(results);
          finder.find(results.rest.isEmpty ? ['.'] : results.rest, fileOptions);
        }
      }
    } on FormatException catch (exc) {
      usage(exc.toString());
    }
    return finder;
  }
}

class FileInfo {
  final String name;
  final int size;
  Digest hashStart;
  Digest hashFull;

  FileInfo(this.name, this.size);
}
