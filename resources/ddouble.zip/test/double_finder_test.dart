import 'dart:io';

import 'package:path/path.dart';
import 'package:test/test.dart';
import 'package:ddouble/helper.dart';
import 'package:ddouble/double_finder.dart';

void main(){
  final baseDirectory = init();
  final txtFilePattern = join(baseDirectory, '*.txt');
  DoubleFinder.storeResult = true;
  test('standard', ()
  {
    final finder = DoubleFinder.execute(['-V', '4', baseDirectory]);
    expect(finder, isNotNull);
    expect(finder.lines.length, 2);
    expect(finder.lines[0], matches(RegExp(r'\S+text4.txt = \S+text3.txt size: 54')));
    expect(finder.lines[1], matches(RegExp(r'\S+text6.txt = \S+text3.txt size: 54')));
  });
}
String init() {
  final content1 = '12345789_12345789_12345789_12345789_12345789_1234';
  final base = join(Directory.systemTemp.path, 'ddouble');
  writeString(join(base, 'text1.txt'), string: content1 + 'fdklsafdslafdsafda');
  writeString(join(base, 'text2.txt'), string: '333');
  writeString(join(base, 'dir1', 'text3.txt'), string: content1 + '12345');
  writeString(join(base, 'dir1', 'text4.txt'), string: content1 + '12345');
  writeString(join(base, 'dir2', 'text5.txt'), string: content1 + 'nix');
  writeString(join(base, 'dir3', 'text6.txt'), string: content1 + '12345');
  return base;
}
