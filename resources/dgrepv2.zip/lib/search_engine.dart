import 'dart:io';

import 'package:args/args.dart';
import 'package:path/path.dart';

import 'file_supplier.dart';
import 'helper.dart';

/// Shows a message how to use the program.
/// [message]: null or an error message
/// [parser]: delivers the description of the program's options
void usage(String message, {ArgParser parser}) {
  print('''Usage: dgrep [<options>] <pattern> <file1> [<file2>] ..
  Searches <pattern> in <file1> <file2>...
  <fileN>: a directory or a shell file pattern like '*.txt'
    or both like /home/*.txt

Examples:
 dgrep -r "version.*2"
 dgrep -V2 -i -r "happy|lucky" "*.txt" "--excluded=test.*" "--excluded-dirs=.git|.config" 
<option>:''');
  if (parser == null) {
    print('  Use -h or --help for more info');
  } else {
    print(parser.usage);
  }
  if (message != null) {
    print('+++ ' + message);
  }
}

class SearchEngine {
  static bool storeResult = false;
  final startTime = DateTime.now();
  final List<String> filePatterns;
  final String pattern;
  final SearchOptions searchOptions;
  final FileOptions fileOptions;
  int totalHitLines = 0;
  int totalHitFiles = 0;
  int verboseLevel = 1;
  RegExp regExp;
  String rc;
  final lines = <String>[];
  final formatPlaceholders = RegExp(r'%[#fpnFehcl1-9]%');

  SearchEngine(this.pattern, this.filePatterns,
      {this.fileOptions, this.searchOptions, this.verboseLevel = 0});

  /// Creates an output line depending on a given [format].
  String formatLine(
      String format, String file, String line, int lineNo, String prefix,
      {RegExpMatch match, int hits}) {
    String line2;
    if (format == null) {
      line2 = '$prefix$file-$lineNo: $line';
    } else {
      line2 = searchOptions.format;
      for (var match2 in formatPlaceholders.allMatches(format)) {
        final placeholder = match2.group(0);
        switch (placeholder[1]) {
          case '#':
            line2 = line2.replaceAll(placeholder, lineNo.toString());
            break;
          case 'f':
            line2 = line2.replaceAll(placeholder, file);
            break;
          case 'p':
            line2 = line2.replaceAll(placeholder, dirname(file));
            break;
          case 'n':
            line2 = line2.replaceAll(placeholder, basename(file));
            break;
          case 'F':
            line2 =
                line2.replaceAll(placeholder, basenameWithoutExtension(file));
            break;
          case 'e':
            line2 = line2.replaceAll(placeholder, extension(file));
            break;
          case 'h':
            line2 = line2.replaceAll(placeholder, match?.group(0) ?? '');
            break;
          case 'c':
            line2 = line2.replaceAll(placeholder, hits?.toString() ?? '');
            break;
          case 'l':
            line2 = line2.replaceAll(placeholder, line);
            break;
          case '1':
          case '2':
          case '3':
          case '4':
          case '5':
          case '6':
          case '7':
          case '8':
          case '9':
            final groupNo = placeholder.codeUnitAt(1) - '0'.codeUnitAt(0);
            line2 = line2.replaceAll(placeholder, match?.group(groupNo) ?? '');
            break;
          default:
            break;
        }
      }
    }
    return line2;
  }
  // Searches the files using the FileSupplier class and applies the text search.
  void search() {
    String exitMessage;
    try {
      final pattern2 = searchOptions.word ? '\\b$pattern\\b' : pattern;
      regExp = RegExp(pattern2, caseSensitive: !searchOptions.ignoreCase);
      fileOptions.yieldDirectory = false;
      fileOptions.yieldLinkToDirectory = false;
      final supplier = FileSupplier(
          fileOptions: fileOptions,
          filePatterns: filePatterns,
          verboseLevel: verboseLevel);
      try {
        for (var filename in supplier.next()) {
          if (!searchFile(filename)) {
            supplier.ignoredFiles++;
            supplier.processedFiles--;
            if (verboseLevel >= 4) {
              print('= ignored because of access: $filename');
            }
          }
        }
      } on ExitException catch (exc) {
        exitMessage = '= search stopped: ' + exc.reason;
      }
      if (verboseLevel >= 1) {
        var hits = searchOptions.count || searchOptions.list
            ? ''
            : ' matching lines: $totalHitLines';
        print(supplier.summary[0] + hits);
        print(supplier.summary.sublist(1).join('\n'));
        final diff = DateTime.now().difference(startTime);
        final msec = (diff.inMilliseconds % 1000).toString().padLeft(3, '0');
        print(
            '= runtime: ${diff.inHours}h${diff.inMinutes % 60}m${diff.inSeconds % 60}.$msec');
        if (exitMessage != null) {
          print(exitMessage);
        }
      }
    } on FormatException catch (exc) {
      usage('error in regular expression "$pattern": $exc');
    }
    if (!SearchEngine.storeResult) {
      // Exit at once: Perhaps no garbage collection.
      exit(0);
    }
  }

  /// Read the [file]'s content and search for the search pattern respecting
  /// the search options.
  /// Uses [showLine()] to show the matching lines.
  /// Returns true: success false: no success
  bool searchFile(String file) {
    var rc = true;
    if (verboseLevel >= 3) {
      print('= processing $file ...');
    }
    try {
      final lines = File(file).readAsLinesSync();
      var hitLines = 0;
      var lineNo = 0;
      var lastShowedLine = 0;
      var aboveBound = 0;
      var line2;
      final prefixMatch =
          searchOptions.belowContext > 0 || searchOptions.aboveContext > 0
              ? '='
              : '';
      for (var line in lines) {
        lineNo++;
        final match = regExp.firstMatch(line);
        final isHit = !searchOptions.invertMatch && match != null ||
            searchOptions.invertMatch && match == null;
        if (!isHit) {
          if (lineNo <= aboveBound) {
            line2 = formatLine(
                searchOptions.formatContext, file, line, lineNo, '>');
            showLine(line2);
            lastShowedLine = lineNo;
          }
        } else {
          hitLines++;
          totalHitLines++;
          if (searchOptions.list) {
            showLine(file);
            break;
          }
          aboveBound = lineNo + searchOptions.aboveContext;
          if (!searchOptions.count) {
            if (searchOptions.belowContext > 0) {
              for (var lineNo2 = lineNo - searchOptions.belowContext;
                  lineNo2 < lineNo;
                  lineNo2++) {
                if (lineNo2 > lastShowedLine) {
                  line2 = formatLine(searchOptions.formatContext, file,
                      lines[lineNo2 - 1], lineNo2, '<');
                  showLine(line2);
                }
              }
            }
            line2 = formatLine(
                searchOptions.format, file, line, lineNo, prefixMatch,
                match: match);
            showLine(line2);
            lastShowedLine = lineNo;
          }
          if (searchOptions.exitLines != null &&
              totalHitLines >= searchOptions.exitLines) {
            throw ExitException('hit lines: $totalHitLines');
          }
          if (searchOptions.breakLines != null &&
              hitLines >= searchOptions.breakLines) {
            break;
          }
        }
        if (searchOptions.exitLines != null &&
            totalHitLines >= searchOptions.exitLines) {
          throw ExitException('exit lines: $totalHitLines');
        }
      }
      if (searchOptions.count) {
        showLine(searchOptions.format == null
            ? '$hitLines $file'
            : formatLine(searchOptions.format, file, '', 0, '',
                hits: hitLines));
      }
      if (hitLines > 0) {
        totalHitFiles++;
        if (searchOptions.exitFiles != null &&
            totalHitFiles >= searchOptions.exitFiles) {
          throw ExitException('exit files: $totalHitFiles');
        }
      }
    } on FileSystemException {
      rc = false;
    }
    return rc;
  }

  /// Prints or stores the output line, depending on the option [storeResult].
  void showLine(String line) {
    if (storeResult) {
      lines.add(line);
    } else {
      print(line);
    }
  }

  // Adds all boolean options to the argument [parser].
  static void addFlags(ArgParser parser) {
    parser.addFlag('count',
        abbr: 'c',
        help: 'Show only the count of lines with hits (per file)',
        negatable: false);
    parser.addFlag('ignore-case',
        abbr: 'i', help: 'The search is case insensitive', negatable: false);
    parser.addFlag('invert-match',
        abbr: 'v',
        help: 'Show lines that do not contain the pattern',
        negatable: false);
    parser.addFlag('process-binaries',
        help: 'Normally binary files will not be processed', negatable: false);
    parser.addFlag('help',
        abbr: 'h', help: 'Show the command description', negatable: false);
    parser.addFlag('list',
        abbr: 'l',
        help: 'Show the filename only, not the matching lines',
        negatable: false);
    parser.addFlag('recursive',
        abbr: 'r',
        help: 'Searches in all sub directories too',
        negatable: false);
    parser.addFlag('word',
        abbr: 'w',
        help:
            'The pattern describes a word: a hit will be delimited by word boundaries',
        negatable: false);
  }

  // Adds all not boolean options to the argument [parser].
  static void addOptions(ArgParser parser) {
    parser.addOption('excluded',
        abbr: 'x',
        help: 'A regular expression for files to skip, e.g. ".*\.(bak|sic)"');
    parser.addOption('excluded-dirs',
        abbr: 'X',
        help:
            'A regular expression for directory to skip, e.g. "test|\.git|\.config');
    parser.addOption('format',
        abbr: 'f', help: r'''Describes the format of a found line
The format is a string with placeholders. 
Example: The name of the file is "/doc/data.txt", the search pattern is "(\w+).* (\d+\.\d\d) "
  the found line is "apples: 20 kg 20.00 EUR"
%f% full name of the file, e.g. "/doc/data.txt"
%p% the path of the file, e.g. "/doc"
%n% the node, e.g. "data.txt"
%F% the filename, e.g. "data"
%e% the extension, e.g. ".txt"
%#% the line number
%h% the hit, e.g. ": 20 "
%c% the count of hit lines. Only meaningful together with option "--count"
%l% the line with the hit, e.g. "apples: 20 kg 20.00 EUR"
%1% the first group, e.g. "apple"
%2% the 2.nd group, e.g. "20.00"
...
%9% the 9.th group, e.g. "" (not found)
A meaningful format of the above example: "%f%: product: %1% price: %2%"
''');
    parser.addOption('format-context',
        abbr: 'F',
        help: r'''Describes the format of a context line (see above-context...)
The format is a string with placeholders like the option --format.
''');
    parser.addOption('above-context',
        abbr: 'a',
        help: 'That number of lines above the hit line will be showed',
        defaultsTo: '0');
    parser.addOption('context',
        abbr: 'C',
        help:
            'That number of lines above and below the hit line will be showed',
        defaultsTo: '0');
    parser.addOption('below-context',
        abbr: 'b',
        help: 'That number of lines below the hit line will be showed',
        defaultsTo: '0');
    parser.addOption('break-lines',
        help:
            'Stops the search in a file if that number of matching lines is reached');
    parser.addOption('exit-lines',
        help:
            'Stops the search if that number of matching lines is reached (over all files)');
    parser.addOption('exit-files',
        help:
            'Stops the search if that number of files with matching lines is reached');
    parser.addOption('verbose-level',
        abbr: 'V',
        help: '0: no additional info 1: summary 2: detail 3: loop 4: fine',
        defaultsTo: '0');
  }

  /// Executes the total search defined by the program [arguments].
  static SearchEngine execute(List<String> arguments) {
    SearchEngine engine;
    final parser = ArgParser();
    addFlags(parser);
    addOptions(parser);
    try {
      final results = parser.parse(arguments);
      final intArgs = [
        'above-context',
        'context',
        'below-context',
        'break-lines',
        'exit-lines',
        'exit-files',
        'verbose-level'
      ];
      if (results['help']) {
        usage(null, parser: parser);
      } else if (results.rest.isEmpty) {
        usage('too few arguments');
      } else if (testIntArguments(results, intArgs, usage) &&
          testRegExpArguments(results, ['excluded', 'excluded-dirs'], usage)) {
        if (results.rest.isEmpty) {
          usage('too few arguments', parser: parser);
        } else {
          engine = SearchEngine(results.rest[0],
              results.rest.length == 1 ? ['.'] : results.rest.sublist(1),
              searchOptions: SearchOptions.fromArgument(results),
              verboseLevel: intValue(results['verbose-level']),
              fileOptions: FileOptions.fromArgument(results));
          engine.search();
        }
      }
    } on FormatException catch (exc) {
      usage(exc.toString());
    }
    return engine;
  }
}

/// Storing options for text search.
class SearchOptions {
  bool count;
  bool ignoreCase;
  bool invertMatch;
  bool list;
  bool word;
  String format;
  String formatContext;
  int aboveContext;
  int belowContext;
  int breakLines;
  int exitLines;
  int exitFiles;

  SearchOptions(
      {this.count = false,
      this.ignoreCase = false,
      this.invertMatch = false,
      this.list = false,
      this.word = false,
      this.format,
      this.formatContext,
      this.aboveContext = 0,
      this.belowContext = 0,
      this.exitFiles,
      this.breakLines,
      this.exitLines});

  SearchOptions.fromArgument(ArgResults results) {
    count = results['count'];
    ignoreCase = results['ignore-case'];
    invertMatch = results['invert-match'];
    list = results['list'];
    word = results['word'];
    format = results['format'];
    formatContext = results['format-context'];
    aboveContext = intValue(results['above-context']);
    belowContext = intValue(results['below-context']);
    final context = intValue(results['context']);
    if (context > 0) {
      aboveContext = belowContext = context;
    }
    breakLines = intValue(results['break-lines']);
    exitLines = intValue(results['exit-lines']);
    exitFiles = intValue(results['exit-files']);
  }
}
