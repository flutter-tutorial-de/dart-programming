import 'dart:io';

import 'package:dgrep/helper.dart';
import 'package:dgrep/search_engine.dart';
import 'package:path/path.dart';
import 'package:test/test.dart';

void main() {
  final baseDirectory = init();
  final txtFilePattern = join(baseDirectory, '*.txt');
  SearchEngine.storeResult = true;

  group('search', () {
    test('recursive search', () {
      final engine = SearchEngine.execute([
        r'\d',
        '*.y~!X',
        txtFilePattern,
        '--recursive',
      ]);
      expect(engine.lines.length, 3);
      expect(engine.lines[0],
          endsWith('text1.txt-2: 3 Chinesen mit dem Kontrabass.'));
      expect(engine.lines[1], endsWith('text2.txt-1: Teil2'));
      expect(engine.lines[2], endsWith('text2.txt-3: In Zeile 3, TEIL 3'));
    });
    test('option --count', () {
      final engine = SearchEngine.execute([
        r'\d',
        txtFilePattern,
        '-r',
        '--count',
      ]);
      expect(engine.lines.length, 2);
      expect(engine.lines[0], matches(RegExp(r'1 .*text1.txt$')));
      expect(engine.lines[1], matches(RegExp(r'2 .*text2.txt$')));
    });
    test('option --ignore-case', () {
      final engine = SearchEngine.execute([
        r'teil',
        txtFilePattern,
        '--recursive',
        '--ignore-case',
        '-i',
      ]);

      expect(engine.lines.length, 2);
      expect(engine.lines[0], endsWith('text2.txt-1: Teil2'));
      expect(engine.lines[1], endsWith('text2.txt-3: In Zeile 3, TEIL 3'));
    });
    test('option --invert-match', () {
      final engine = SearchEngine.execute([
        r'\d',
        txtFilePattern,
        '--recursive',
        '-v',
      ]);
      expect(engine.lines.length, 3);
      expect(engine.lines[0], endsWith('text1.txt-1: Eine Zeile ohne Zahl.'));
      expect(engine.lines[1], endsWith('text1.txt-3: Blub'));
      expect(engine.lines[2], endsWith('text2.txt-2: der Rest steht:'));
    });
    test('option --list', () {
      final engine = SearchEngine.execute(
          [r'\d', txtFilePattern, '--recursive', '--list', '-l']);
      expect(engine.lines.length, 2);
      expect(engine.lines[0], endsWith('text1.txt'));
      expect(engine.lines[1], endsWith('text2.txt'));
    });
    test('option --word', () {
      final engine = SearchEngine.execute(
          [r'teil', txtFilePattern, '--recursive', '--word', '-w', '-i']);
      expect(engine.lines.length, 1);
      expect(engine.lines[0], endsWith('text2.txt-3: In Zeile 3, TEIL 3'));
    });
    test('option --format', () {
      final engine = SearchEngine.execute([
        r'(\d+)\s+([C]\w+)',
        txtFilePattern,
        r'--format=Treffer: %n% %F% %e% %h% %#% p: %p%: f: %f%; %1% %2% %l%!',
      ]);
      expect(engine.lines.length, 1);
      expect(engine.lines[0],
          startsWith('Treffer: text1.txt text1 .txt 3 Chinesen 2 p:'));
      expect(engine.lines[0], endsWith('3 Chinesen mit dem Kontrabass.!'));
      expect(engine.lines[0], matches(RegExp(r'p: .*dgrep:')));
      expect(engine.lines[0], matches(RegExp(r'f: .*text1.txt;')));
    });
    test('option --format --count', () {
      final engine = SearchEngine.execute([
        r'\d',
        txtFilePattern,
        '--recursive',
        '-f',
        'Treffer: %c% Datei: %#% %n% %F% %e% %f%',
        '-c',
      ]);

      expect(engine.lines.length, 2);
      expect(
          engine.lines[0],
          matches(RegExp(
              r'^Treffer: 1 Datei: 0 text1.txt text1 .txt \S+text1.txt$')));
      expect(
          engine.lines[1],
          matches(RegExp(
              r'^Treffer: 2 Datei: 0 text2.txt text2 .txt \S+text2.txt$')));
    });
    test('option --above-context --below-context', () {
      final engine = SearchEngine.execute([
        r'toll',
        join(baseDirectory, '*.text'),
        '--recursive',
        '--below-context=1',
        '--above-context',
        '2',
      ]);
      expect(engine.lines.length, 9);
      expect(engine.lines[0], matches(RegExp(r'<\S+text3.text-2: nix2$')));
      expect(engine.lines[1], matches(RegExp(r'=\S+text3.text-3: toll3$')));
      expect(engine.lines[2], matches(RegExp(r'>\S+text3.text-4: nix4$')));
      expect(engine.lines[3], matches(RegExp(r'=\S+text3.text-5: toll5$')));
      expect(engine.lines[4], matches(RegExp(r'>\S+text3.text-6: nix6$')));
      expect(engine.lines[5], matches(RegExp(r'>\S+text3.text-7: nix7$')));
      expect(engine.lines[6], matches(RegExp(r'<\S+text3.text-8: nix8$')));
      expect(engine.lines[7], matches(RegExp(r'=\S+text3.text-9: toll9$')));
      expect(engine.lines[8], matches(RegExp(r'>\S+text3.text-10: nix10$')));
    });
    test('option --break-lines', () {
      final engine = SearchEngine.execute([
        r'\d',
        txtFilePattern,
        '--recursive',
        '-v',
        '--break-lines=1',
      ]);

      expect(engine.lines.length, 2);
      expect(engine.lines[0], endsWith('text1.txt-1: Eine Zeile ohne Zahl.'));
      expect(engine.lines[1], endsWith('text2.txt-2: der Rest steht:'));
    });
    test('option --exit-files', () {
      final engine = SearchEngine.execute([
        r'\d',
        txtFilePattern,
        '--recursive',
        '--exit-files=1',
      ]);
      expect(engine.lines.length, 1);
      expect(engine.lines[0],
          endsWith('text1.txt-2: 3 Chinesen mit dem Kontrabass.'));
    });
    test('option --exit-lines', () {
      final engine = SearchEngine.execute([
        r'\d',
        txtFilePattern,
        '--recursive',
        '--exit-lines',
        '2',
      ]);

      expect(engine.lines.length, 2);
      expect(engine.lines[0],
          endsWith('text1.txt-2: 3 Chinesen mit dem Kontrabass.'));
      expect(engine.lines[1], endsWith('text2.txt-1: Teil2'));
    });
  });
  group('errors', () {
    test('wrong pattern', () {
      final engine = SearchEngine.execute([r'*', '.']);
      expect(engine.lines.length, 0);
    });
    test('unknown option', () {
      final engine = SearchEngine.execute([r'nixda', '*.nix', '--none-known']);
      expect(engine, isNull);
    });
    test('to few arguments', () {
      final engine = SearchEngine.execute([]);
      expect(engine, isNull);
    });
  });
}

String init() {
  final base = join(Directory.systemTemp.path, 'dgrep');
  writeString(join(base, 'text1.txt'), string: '''Eine Zeile ohne Zahl.
3 Chinesen mit dem Kontrabass.
Blub
''');
  writeString(join(base, 'text1.data'), string: '333');
  final file2 = join(base, 'dir1', 'text2.txt');
  writeString(file2, string: 'Teil2\nder Rest steht:\nIn Zeile 3, TEIL 3');
  final file3 = join(base, 'dir1', 'text3.text');
  writeString(file3, string: '''nix1
nix2
toll3
nix4
toll5
nix6
nix7
nix8
toll9
nix10
''');
  return base;
}
