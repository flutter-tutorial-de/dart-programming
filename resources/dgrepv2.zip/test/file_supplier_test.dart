import 'dart:io';

import 'package:dgrep/file_supplier.dart';
import 'package:dgrep/helper.dart';
import 'package:dgrep/search_engine.dart';
import 'package:path/path.dart' as path;
import 'package:test/test.dart';

void main() {
  final baseDirectory = init();
  SearchEngine.storeResult = true;
  group('FileSupplier', () {
    test('flat search', () {
      final supplier = FileSupplier(
          filePatterns: [baseDirectory],
          fileOptions: FileOptions(yieldDirectory: false));
      final list = toList(supplier);
      expect(list.length, Platform.isLinux ? 3 : 2);
      expect(list[0], endsWith('text1.txt'));
      expect(list[1], endsWith('text2.data'));
      if (Platform.isLinux) {
        expect(list[2], endsWith('double'));
      }
    });
    test('recursive search', () {
      final supplier = FileSupplier(
          filePatterns: [path.join(baseDirectory, '*.text')],
          fileOptions: FileOptions(
              recursive: true,
              yieldDirectory: false,
              yieldLinkToDirectory: false));
      final list = toList(supplier);
      expect(list.length, 2);
      expect(list[0], endsWith('charly4.text'));
      expect(list[1], endsWith('eve7.text'));
      expect(
          list[1], matches(RegExp(r'file_supplier\Wdir2\Wdir2_2\Weve7.text')));
    });
    test('excluded files', () {
      final supplier = FileSupplier(
          filePatterns: [path.join(baseDirectory, '*.txt')],
          fileOptions: FileOptions(
              recursive: true,
              excluded: RegExp(r'adam.*|eve.*'),
              yieldDirectory: false,
              yieldLinkToDirectory: false));
      final list = toList(supplier);
      expect(list.length, 1);
      expect(list[0], endsWith('text1.txt'));
    });
    test('excluded dirs', () {
      final supplier = FileSupplier(
          filePatterns: [path.join(baseDirectory, '*.txt')],
          fileOptions: FileOptions(
              recursive: true,
              excludedDirs: RegExp(r'dir2.*'),
              yieldDirectory: false,
              yieldLinkToDirectory: false));
      final list = toList(supplier);
      expect(list.length, 2);
      expect(list[0], endsWith('text1.txt'));
      expect(list[1], endsWith('adam3.txt'));
    });
    test('file type: dirs only', () {
      final supplier = FileSupplier(
          filePatterns: [baseDirectory],
          fileOptions: FileOptions(
              recursive: true, yieldFile: false, yieldLinkToDirectory: false));
      final list = toList(supplier);
      expect(list.length, 3);
      expect(list[0], endsWith('dir1'));
      expect(list[1], endsWith('dir2'));
      expect(list[2], endsWith('dir2_2'));
    });
    test('file type: links only', () {
      final supplier = FileSupplier(
          filePatterns: [baseDirectory],
          fileOptions: FileOptions(
              recursive: true, yieldFile: false, yieldDirectory: false));
      final list = toList(supplier);
      if (!Platform.isLinux) {
        expect(list.length, 0);
      } else {
        expect(list.length, 1);
        expect(list[0], endsWith('double'));
      }
    });
  });
}

String init() {
  final base = path.join(Directory.systemTemp.path, 'file_supplier');
  var fileNo = 0;
  writeString(path.join(base, 'text${++fileNo}.txt'), string: 'Blub');
  writeString(path.join(base, 'text${++fileNo}.data'), string: '333');
  writeString(path.join(base, 'dir1', 'adam${++fileNo}.txt'), string: 'Teil2');
  writeString(path.join(base, 'dir1', 'charly${++fileNo}.text'),
      string: 'Huuuuu');
  writeString(path.join(base, 'dir2', 'adam${++fileNo}.txt'), string: 'Hm');
  writeString(path.join(base, 'dir2', 'dir2_2', 'adam${++fileNo}.txt'),
      string: 'Hm');
  writeString(path.join(base, 'dir2', 'dir2_2', 'eve${++fileNo}.text'),
      string: 'Hm');
  final link = path.join(base, 'double');
  if (Platform.isLinux && !Link(link).existsSync()) {
    Link(link).createSync('dir2');
  }
  return base;
}

List<String> toList(FileSupplier supplier) => supplier.next().toList();
