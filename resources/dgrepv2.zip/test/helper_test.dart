import 'dart:io';
import 'package:dgrep/helper.dart';
import 'package:test/test.dart';
import 'package:args/args.dart';
import 'package:path/path.dart' as path;

void main() {
  group('argument handling', () {
    test('testIntArguments', () {
      final parser = ArgParser();
      parser.addOption('count');
      parser.addOption('positive-number');
      parser.addFlag('recursive');
      final result = parser
          .parse(['--positive-number', '33', '--recursive', '--count=nix']);
      var message;
      expect(
          testIntArguments(
              result, ['positive-number'], (error) => message = error),
          true);
      expect(
          testIntArguments(
              result, ['positive-number', 'count'], (error) => message = error),
          false);
      expect(message, contains('count is not an integer: nix'));
    });
    test('testRegExpArguments', () {
      final parser = ArgParser();
      parser.addOption('excluded');
      parser.addOption('included', abbr: 'i');
      final result = parser.parse(['--excluded=*', '-i', r'.*\.(doc|txt)']);
      var message;
      expect(
          testRegExpArguments(result, ['included'], (error) => message = error),
          true);
      expect(
          testRegExpArguments(
              result, ['included', 'excluded'], (error) => message = error),
          false);
      expect(message, contains('excluded: error in regular expression'));
    });
  });
  test('regExpEscape', () {
    expect(regExpEscape('()[]{}?*+-|^\$\\.&~# '),
        equals('\\(\\)\\[\\]\\{\\}\\?\\*\\+\\-\\|\\^\\\$\\\\\\.\\&\\~\\#\\ '));
    expect(regExpEscape('abc.123'), equals(r'abc\.123'));
    expect(regExpEscape(''), equals(r''));
    expect(regExpEscape(null), isNull);
  });
  test('shellPatternToRegExp', () {
    expect(shellPatternToRegExp('*.txt'), equals(r'^.*\.txt$'));
    expect(shellPatternToRegExp('*.txt', addBeginOfString: false),
        equals(r'.*\.txt$'));
    expect(shellPatternToRegExp('*.txt', addEndOfString: false),
        equals(r'^.*\.txt'));
    expect(shellPatternToRegExp('*.txt', addEndOfString: false),
        equals(r'^.*\.txt'));
    expect(shellPatternToRegExp('0[a-f][!] -!]'), equals(r'^0[a-f][^\] -!]$'));
    expect(shellPatternToRegExp(''), equals(r'^$'));
    expect(shellPatternToRegExp(null), isNull);
  });
  test('isBinary', () {
    final base = path.join(Directory.systemTemp.path, 'helper');
    final file1 = path.join(base, 'notBinary.01');
    writeString(file1, string: 'abc\r\n\t\f');
    expect(isBinary(file1), isFalse);
    final file2 = File(path.join(base, 'binary.02'));
    final handle1 = file2.openSync(mode: FileMode.write);
    handle1.writeByteSync(0);
    handle1.writeByteSync(33);
    handle1.closeSync();
    expect(isBinary(file2.path), isTrue);
    final file3 = File(path.join(base, 'binary.02'));
    final handle2 = file3.openSync(mode: FileMode.write);
    for (var no = 1; no < 32; no++) {
      handle2.writeByteSync(no);
    }
    handle2.closeSync();
    expect(isBinary(file3.path), isTrue);
  });
  test('intValue', () {
    expect(intValue('93'), 93);
    expect(intValue('-12344'), -12344);
    expect(intValue(''), isNull);
    expect(intValue(null), isNull);
  });
}
